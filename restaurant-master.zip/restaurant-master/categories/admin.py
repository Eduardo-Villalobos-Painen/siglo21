from django.contrib import admin
from categories.models import Categoria


# Register your models here.

@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    pass